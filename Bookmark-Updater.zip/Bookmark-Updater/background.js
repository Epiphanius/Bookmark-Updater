// Konfiguration
const TIMER_DELAY_MS = 60000; // Automatische Speicherung nach 60 Sek. Inaktivität
let activeTimers = {};

// Optimierte Hilfsfunktion: Holt den reinen Buchordner ohne Zusätze
function getBookTitle(url) {
  if (!url || !url.startsWith("file://")) return null;
  
  // URL in Segmente teilen und leere Einträge herausfiltern
  const parts = url.split("/").filter(p => p.length > 0);
  
  if (parts.length > 2) {
    // Letzter Ordner direkt vor dem Dateinamen
    let bookFolder = parts[parts.length - 2];
    
    // Falls der Ordner "imagepages" heißt, eine Ebene höher springen
    if (bookFolder.toLowerCase() === "imagepages" && parts.length > 3) {
      bookFolder = parts[parts.length - 3];
    }
    
    // URL-Kodierung (z.B. %20 zu Leerzeichen) auflösen und Namen zurückgeben
    return decodeURIComponent(bookFolder).trim();
  }
  
  return "Mein Buch";
}

// Visuelles Feedback über das Icon senden (Badge)
function showVisualFeedback(tabId, success) {
  const text = success ? "OK" : "ERR";
  const color = success ? "#2ecc71" : "#e74c3c"; // Grün für Erfolg, Rot für Fehler

  browser.action.setBadgeText({ text: text, tabId: tabId });
  browser.action.setBadgeBackgroundColor({ color: color, tabId: tabId });

  // Nach 2.5 Sekunden das Feedback wieder ausblenden
  setTimeout(() => {
    browser.action.setBadgeText({ text: "", tabId: tabId });
  }, 2500);
}

// Kern-Funktion zum Suchen und Updaten/Erstellen des Lesezeichens
async function updateBookmark(tab) {
  if (!tab || !tab.url || !tab.url.startsWith("file://")) {
    console.log("Keine gültige lokale Datei.");
    return;
  }

  const bookTitle = getBookTitle(tab.url);
  if (!bookTitle) return;

  try {
    // Nach exakt diesem Buchtitel suchen
    const found = await browser.bookmarks.search({ title: bookTitle });
    
    if (found.length > 0) {
      // Existierendes Lesezeichen aktualisieren
      await browser.bookmarks.update(found[0].id, { url: tab.url });
      console.log(`Lesezeichen erfolgreich aktualisiert: ${bookTitle}`);
    } else {
      // Neues Lesezeichen erstellen, falls es noch nicht existiert
      await browser.bookmarks.create({ title: bookTitle, url: tab.url });
      console.log(`Neues Lesezeichen angelegt: ${bookTitle}`);
    }
    showVisualFeedback(tab.id, true);
  } catch (err) {
    showVisualFeedback(tab.id, false);
    console.error("Fehler beim Lesezeichen-Vorgang:", err);
  }
}

// EVENT 1: Manueller Klick auf das Add-on Icon
browser.action.onClicked.addListener((tab) => {
  updateBookmark(tab);
});

// EVENT 2: Automatisches Update beim Wechseln der HTML-Seite (mit 60s Verzögerung)
browser.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url && changeInfo.url.startsWith("file://")) {
    if (activeTimers[tabId]) clearTimeout(activeTimers[tabId]);

    activeTimers[tabId] = setTimeout(() => {
      updateBookmark(tab);
    }, TIMER_DELAY_MS);
  }
});

// EVENT 3: Timer löschen, wenn Tab geschlossen wird
browser.tabs.onRemoved.addListener((tabId) => {
  if (activeTimers[tabId]) {
    clearTimeout(activeTimers[tabId]);
    delete activeTimers[tabId];
  }
});

